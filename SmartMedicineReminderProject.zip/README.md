# IoT Smart Medicine Reminder

Prototype using ESP32, DS3231, OLED, Servo, Button, LED, Buzzer and Firebase/Blynk.

## Files
- SmartMedicineReminder.ino
- wifi_config.h
- firebase_config.h
- rtc_manager.h
- oled_display.h
- servo_control.h
- reminder_logic.h

Replace Wi-Fi credentials and Firebase credentials before uploading.
