#include <WiFi.h>
#include <Wire.h>
#include <RTClib.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ESP32Servo.h>
#include "wifi_config.h"

RTC_DS3231 rtc;
Adafruit_SSD1306 display(128,64,&Wire,-1);
Servo servoMotor;

const int SERVO_PIN=18,BUZZER=25,LED=26,BUTTON=27;
struct MedicineSchedule{const char* name;int h;int m;};
MedicineSchedule meds[]={
{"Paracetamol",8,0},
{"Vitamin C",14,0},
{"BP Tablet",20,0}
};

void connectWiFi(){
 WiFi.begin(WIFI_SSID,WIFI_PASSWORD);
 while(WiFi.status()!=WL_CONNECTED){delay(500);}
}
void setup(){
 pinMode(BUZZER,OUTPUT);
 pinMode(LED,OUTPUT);
 pinMode(BUTTON,INPUT_PULLUP);
 servoMotor.attach(SERVO_PIN);
 Wire.begin();
 rtc.begin();
 display.begin(SSD1306_SWITCHCAPVCC,0x3C);
 connectWiFi();
}
void remind(const char* med){
 display.clearDisplay();
 display.setCursor(0,0);
 display.setTextSize(1);
 display.setTextColor(SSD1306_WHITE);
 display.println("Take Medicine");
 display.println(med);
 display.display();
 digitalWrite(LED,HIGH);
 tone(BUZZER,2000);
 servoMotor.write(90);
 unsigned long start=millis();
 bool taken=false;
 while(millis()-start<30000){
   if(digitalRead(BUTTON)==LOW){taken=true;break;}
 }
 noTone(BUZZER);
 digitalWrite(LED,LOW);
 servoMotor.write(0);
 display.clearDisplay();
 display.setCursor(0,0);
 display.println(taken?"Medicine Taken":"Dose Missed");
 display.display();
 // TODO: upload status to Firebase/Blynk here
 delay(3000);
}
void loop(){
 DateTime now=rtc.now();
 for(auto &m:meds){
   if(now.hour()==m.h && now.minute()==m.m && now.second()<2){
      remind(m.name);
   }
 }
 delay(500);
}
