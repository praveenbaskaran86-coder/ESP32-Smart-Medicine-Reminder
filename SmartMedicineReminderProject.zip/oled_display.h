#pragma once
void showReminder(const char* med,const char* time);
void showTaken();
void showMissed();
