#pragma once
struct MedicineSchedule{
  const char* name;
  uint8_t hour;
  uint8_t minute;
};
